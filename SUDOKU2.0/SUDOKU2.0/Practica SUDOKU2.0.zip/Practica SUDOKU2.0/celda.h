#pragma once
#include <iostream>
#include <string>

using namespace std;

typedef enum {ORIGINAL, OCUPADA, VACIA} tEstado;

class tCelda {
private:
	int v;
	tEstado estado;

public:

	tCelda();
	tCelda(int v);
	/* m�todos de consulta */


	bool es_vacia() const;
	bool es_original() const;
	bool es_ocupada() const;
	int dame_valor() const;
	/* m�todos modificadores*/
	void set_valor(int v);
	void set_ocupada();
	void set_original();
	void set_vacia();

};
#pragma once
